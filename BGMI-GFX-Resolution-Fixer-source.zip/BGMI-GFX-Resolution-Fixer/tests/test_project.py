import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / 'app/src/main/java/com/yash/gfxfixer/MainActivity.java').read_text()
MANIFEST = ROOT / 'app/src/main/AndroidManifest.xml'
APP_GRADLE = (ROOT / 'app/build.gradle').read_text()

class ProjectTests(unittest.TestCase):
    def test_manifest_is_valid_xml_and_declares_shizuku_provider(self):
        root = ET.parse(MANIFEST).getroot()
        android = '{http://schemas.android.com/apk/res/android}'
        providers = root.find('application').findall('provider')
        self.assertTrue(any(p.get(android+'name') == 'rikka.shizuku.ShizukuProvider' for p in providers))
        self.assertTrue(any(p.get(android+'name') == 'com.pubg.imobile' for p in root.find('queries').findall('package')))

    def test_shizuku_dependencies_present(self):
        self.assertIn("dev.rikka.shizuku:api:13.1.5", APP_GRADLE)
        self.assertIn("dev.rikka.shizuku:provider:13.1.5", APP_GRADLE)

    def test_permission_flow_does_not_check_version_before_permission(self):
        start = JAVA.index('private void connectShizuku()')
        end = JAVA.index('private boolean hasPermission()', start)
        block = JAVA[start:end]
        version_pos = block.find('Shizuku.getVersion()')
        grant_pos = block.find('Shizuku.checkSelfPermission() ==')
        self.assertGreaterEqual(version_pos, grant_pos, 'getVersion() must not run before checking granted permission')
        self.assertIn('Shizuku.requestPermission(REQUEST_CODE)', block)

    def test_only_targets_bgmi_package_and_never_changes_global_size_or_density(self):
        self.assertIn('private static final String PKG = "com.pubg.imobile";', JAVA)
        self.assertNotIn('runShell(\"wm size', JAVA)
        self.assertNotIn('runShell(\"wm density', JAVA)
        self.assertIn('cmd game set --downscale disable ', JAVA)
        self.assertIn('cmd game reset ', JAVA)

    def test_restore_reports_command_exit_code_and_current_config(self):
        self.assertIn('Reset exit code: %s', JAVA)
        self.assertIn('cmd game list-configs " + PKG', JAVA)

    def test_stdout_and_stderr_are_read_concurrently(self):
        self.assertIn('Thread outReader = new Thread', JAVA)
        self.assertIn('Thread errReader = new Thread', JAVA)
        self.assertLess(JAVA.index('outReader.start()'), JAVA.index('p.waitFor()'))
        self.assertLess(JAVA.index('errReader.start()'), JAVA.index('p.waitFor()'))

    def test_resolution_claim_is_qualified(self):
        self.assertIn('cannot force BGMI', JAVA)
        self.assertIn('may not equal 3D render resolution', JAVA)

if __name__ == '__main__':
    unittest.main(verbosity=2)

package com.yash.gfxfixer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.IBinder;
import android.content.ComponentName;
import android.content.ServiceConnection;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;
import rikka.shizuku.Shizuku.UserServiceArgs;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 4107;
    private static final String PKG = "com.pubg.imobile";
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView status;
    private TextView output;
    private Button connectButton;
    private volatile IShellService shellService;
    private volatile boolean serviceBinding = false;
    private final ServiceConnection shellConnection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            shellService = IShellService.Stub.asInterface(binder);
            serviceBinding = false;
            worker.execute(() -> executeWithUserService(""));
        }
        @Override public void onServiceDisconnected(ComponentName name) { shellService = null; serviceBinding = false; }
    };
    private volatile String pendingCommand;

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode == REQUEST_CODE) {
            refreshStatus();
            toast(grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
                    ? "Shizuku permission granted" : "Shizuku permission denied");
        }
    };

    private final Shizuku.OnBinderReceivedListener binderListener = this::refreshStatus;
    private final Shizuku.OnBinderDeadListener binderDeadListener = this::refreshStatus;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        Shizuku.addBinderReceivedListenerSticky(binderListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        buildUi();
        refreshStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(248, 250, 252));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(24), dp(22), dp(24));
        scroll.addView(page);

        TextView title = text("BGMI GFX Fixer", 28, true, Color.rgb(15, 23, 42));
        page.addView(title);
        TextView subtitle = text("Xiaomi Pad 8 · Shizuku · No root", 14, false, Color.rgb(71, 85, 105));
        LinearLayout.LayoutParams subParams = params(-1, -2); subParams.topMargin = dp(6); page.addView(subtitle, subParams);

        status = text("Checking Shizuku…", 15, true, Color.rgb(30, 64, 175));
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        status.setBackgroundColor(Color.rgb(219, 234, 254));
        LinearLayout.LayoutParams statusParams = params(-1, -2); statusParams.topMargin = dp(20); page.addView(status, statusParams);

        connectButton = button("Connect / Request Shizuku permission");
        connectButton.setOnClickListener(v -> connectShizuku());
        addButton(page, connectButton);
        addButton(page, button("Disable Android game downscaling", v -> runShell(
                "cmd game set --downscale disable " + PKG + "; rc=$?; printf '\\nCommand exit code: %s\\n--- Current game config ---\\n' \"$rc\"; cmd game list-configs " + PKG + "; exit $rc")));
        addButton(page, button("Check current render buffer", v -> runShell(
                "printf '%s\\n' '--- Game Mode config ---'; cmd game list-configs " + PKG + "; printf '%s\\n' '--- SurfaceFlinger game layers (may not equal 3D render resolution) ---'; dumpsys SurfaceFlinger 2>&1 | grep 'SurfaceView\\[" + PKG + "' | head -20")));
        addButton(page, button("Restore Android game-mode defaults", v -> runShell(
                "cmd game reset " + PKG + "; rc=$?; printf '\\nReset exit code: %s\\n--- Config after reset ---\\n' \"$rc\"; cmd game list-configs " + PKG + "; exit $rc")));

        TextView warning = text("Important: this app does not change wm size or density. Android's game-mode command can disable OS downscaling, but it cannot force BGMI's internal Unreal Engine renderer to 1920×1080. The buffer report is diagnostic only and is not proof of the game's 3D render resolution.", 14, false, Color.rgb(71, 85, 105));
        warning.setPadding(dp(14), dp(14), dp(14), dp(14)); warning.setBackgroundColor(Color.rgb(241, 245, 249));
        LinearLayout.LayoutParams warnParams = params(-1, -2); warnParams.topMargin = dp(18); page.addView(warning, warnParams);

        TextView outTitle = text("Command output", 18, true, Color.rgb(15, 23, 42));
        LinearLayout.LayoutParams outTitleParams = params(-1, -2); outTitleParams.topMargin = dp(22); page.addView(outTitle, outTitleParams);
        output = text("No command run yet.", 12, false, Color.rgb(226, 232, 240));
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(14), dp(14), dp(14), dp(14));
        output.setBackgroundColor(Color.rgb(15, 23, 42));
        LinearLayout.LayoutParams outParams = params(-1, -2); outParams.topMargin = dp(8); page.addView(output, outParams);
        setContentView(scroll);
    }

    private Button button(String label) { return button(label, null); }
    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextSize(14); if (listener != null) b.setOnClickListener(listener); return b;
    }
    private void addButton(LinearLayout page, Button b) {
        LinearLayout.LayoutParams p = params(-1, -2); p.topMargin = dp(8); page.addView(b, p);
    }
    private TextView text(String value, int size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void connectShizuku() {
        if (!Shizuku.pingBinder()) {
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Shizuku is not running")
                    .setMessage("Install and start the official Shizuku app, then start its service (Wireless debugging or root). Return here and tap Connect again.")
                    .setPositiveButton("Open Shizuku page", (d, w) -> {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/"))); }
                        catch (Exception ignored) { }
                    }).setNegativeButton("Close", null).show();
            refreshStatus(); return;
        }
        // Check the service generation first. Do not call getVersion() before permission:
        // Shizuku can return -1 when an unprivileged app has not been granted API access yet.
        if (Shizuku.isPreV11()) {
            toast("Please update Shizuku to version 11 or newer"); return;
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            if (Shizuku.getVersion() < 11) {
                toast("Please update Shizuku to version 11 or newer"); return;
            }
            refreshStatus(); toast("Shizuku already connected");
        } else {
            Shizuku.requestPermission(REQUEST_CODE);
        }
    }

    private boolean hasPermission() {
        try { return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED; }
        catch (Exception e) { return false; }
    }
    private void refreshStatus() {
        if (status == null) return;
        main.post(() -> {
            boolean running = Shizuku.pingBinder();
            boolean granted = running && hasPermission();
            status.setText(!running ? "Shizuku service: not running" : granted ? "Shizuku: connected and permission granted" : "Shizuku: running, permission needed");
            status.setTextColor(granted ? Color.rgb(22, 101, 52) : Color.rgb(30, 64, 175));
            status.setBackgroundColor(granted ? Color.rgb(220, 252, 231) : Color.rgb(219, 234, 254));
        });
    }

    private void runShell(String command) {
        if (!hasPermission()) { toast("Connect Shizuku and grant permission first"); connectShizuku(); return; }
        output.setText("Connecting to Shizuku shell service…");
        pendingCommand = command;
        if (shellService != null) {
            worker.execute(() -> executeWithUserService(command));
            return;
        }
        synchronized (this) {
            if (serviceBinding) { output.setText("Shizuku service is already connecting. Tap again in a moment."); return; }
            serviceBinding = true;
        }
        UserServiceArgs args = new UserServiceArgs(new android.content.ComponentName(this, ShellUserService.class))
                .daemon(false).tag("bgmi-gfx-shell").version(1);
        try {
            Shizuku.bindUserService(args, shellConnection);
        } catch (Throwable e) {
            serviceBinding = false;
            output.setText("Could not bind Shizuku service: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    private void executeWithUserService(String command) {
        String actual = command.isEmpty() ? pendingCommand : command;
        if (actual == null || actual.isEmpty()) return;
        String result;
        try {
            IShellService service = shellService;
            if (service == null) throw new IllegalStateException("Shizuku shell service is not connected");
            result = service.execCommand(actual);
        } catch (Throwable e) {
            result = "Command failed: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        }
        final String finalResult = result;
        main.post(() -> output.setText(finalResult));
    }

    private void toast(String message) { main.post(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show()); }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        Shizuku.removeBinderReceivedListener(binderListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        worker.shutdownNow();
        super.onDestroy();
    }
}

package com.yash.gfxfixer;

import android.os.RemoteException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ShellUserService extends IShellService.Stub {
    public ShellUserService() { }

    @Override
    public String execCommand(String command) throws RemoteException {
        StringBuilder result = new StringBuilder();
        Process process = null;
        try {
            process = new ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) result.append(line).append('\n');
            }
            int exit = process.waitFor();
            result.append("\nExit code: ").append(exit);
        } catch (Exception e) {
            result.append("Command failed: ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage());
        } finally {
            if (process != null) process.destroy();
        }
        return result.toString();
    }

    public void destroy() { System.exit(0); }
}

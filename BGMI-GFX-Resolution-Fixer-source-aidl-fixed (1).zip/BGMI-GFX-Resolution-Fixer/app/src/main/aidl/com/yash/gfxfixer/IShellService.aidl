package com.yash.gfxfixer;

interface IShellService {
    String execCommand(String command);
}

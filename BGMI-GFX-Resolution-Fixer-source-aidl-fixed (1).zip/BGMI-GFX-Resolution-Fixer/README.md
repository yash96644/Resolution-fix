# BGMI GFX Resolution Fixer (source project)

A small Android app for Xiaomi Pad 8 / BGMI (`com.pubg.imobile`) that uses Shizuku (no root) to run Android Game Mode diagnostics and disable OS-level game downscaling. It intentionally does **not** change `wm size` or `wm density`.

## What it can and cannot do

- **Disable Android game downscaling:** runs `cmd game set --downscale disable com.pubg.imobile`.
- **Inspect:** shows `cmd game list-configs` and matching SurfaceFlinger layers. SurfaceFlinger buffer dimensions may not be the game's actual 3D render resolution.
- **Restore:** runs `cmd game reset com.pubg.imobile` to remove the custom Game Mode intervention and return to system defaults. This does not restore any unrelated system settings.
- **Cannot force 1920x1080 inside BGMI:** Android's public Game Mode shell interface does not provide a reliable per-app command to force the Unreal Engine render resolution. The app does not pretend otherwise.

## Build APK

Open this folder in Android Studio with internet access, allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

Dependencies: Android Gradle Plugin 8.7.3, compile SDK 35, Shizuku API and provider 13.1.5. The Shizuku provider dependency and manifest entry are included so the app can receive the Shizuku binder. This workspace did not have Android SDK/Gradle installed, so the APK could not be compiled here; this folder contains the source project, not a prebuilt APK. The included static test suite can be run with `python tests/test_project.py`. It checks manifest/provider wiring, dependency declarations, permission ordering, BGMI-only targeting, no global display override commands, concurrent process stream reads, restore diagnostics, and the resolution disclaimer. These are source-level tests only; they do not replace an Android build or an on-device test.

## Fixes made during review

- Fixed the Shizuku connection flow so it does not call `Shizuku.getVersion()` before the app has been granted Shizuku permission. That could previously make a fresh permission request look like an outdated Shizuku service.
- Read stdout and stderr concurrently to avoid a child-process pipe deadlock.
- Make the apply/reset buttons show command exit codes and current Game Mode config even when the operation fails.

## Setup

1. Install the official Shizuku app from `https://shizuku.rikka.app/`.
2. Start Shizuku using Wireless debugging on the tablet (no root required).
3. Install this app, open it, tap **Connect / Request Shizuku permission**, and grant permission.
4. Use **Disable Android game downscaling** or **Check current render buffer**.
5. To undo the custom Game Mode intervention, tap **Restore Android game-mode defaults**.

Use third-party game configuration changes at your own risk. This tool does not edit BGMI files or claim to bypass the game's graphics/device profile.

## Build APK in GitHub Actions (when Android SDK is not installed locally)

This repository includes `.github/workflows/build-apk.yml`. Upload/push the project to a GitHub repository, open **Actions → Build Android APK → Run workflow**, and download the `BGMI-GFX-Resolution-Fixer-debug-apk` artifact after the workflow succeeds. The artifact contains `app-debug.apk`.

This CI workflow has not been executed from this environment. It needs GitHub Actions network access to download Gradle and Android dependencies. A successful build does not prove 1080p rendering; the app only disables Android Game Mode downscaling and reports diagnostic SurfaceFlinger buffers.
